Contenido dinámico

agregados header section y footer section en apariencia > personalizar

agregado menú a header y footer de forma dinámica, texto en el footer y logo en el footer de forma dinámica 

Los archivos del tema fueron autogenerados con underscores continuará personalizándose

Se agregaron 4 bloques de Gutenberg con Advanced Custom Fields: 

Header Section
Title & Description
Three block widget
CTA Banner

Faltan detalles de la version móvil

También se puede ver el sitio en https://custom.showmywebsite.fun/wordpress/
