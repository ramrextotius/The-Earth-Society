Contenido dinamico

agregados header section y footer section en apariencia > personalizar

agregado menu a header y footer de forma dinamica, texto en el footer y logo en el footer de forma dinamica 

Los archivos del tema fueron autogenerados con underscores continuara personalizandose

El tema aun no es responsivo
